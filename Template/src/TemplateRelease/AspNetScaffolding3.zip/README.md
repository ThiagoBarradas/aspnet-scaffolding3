# AspNetScaffoldingTemplate

:construction:

# Read more about

Please, see our wiki for more details about this app.

# How can I contribute?
Please, refer to [CONTRIBUTING](.github/CONTRIBUTING.md)

# Found something strange or need a new feature?
Open a new Issue following our [ISSUE TEMPLATE](.github/ISSUE_TEMPLATE.md)