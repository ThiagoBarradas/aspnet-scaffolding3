﻿namespace $ext_safeprojectname$.Models.Person.Composition
{
    public class Address
    {
    }
}
