﻿namespace $ext_safeprojectname$.Models.Person.Composition
{
    public enum PersonType
    {
        Undefined,
        PhysicalPerson,
        LegalEntity
    }
}
