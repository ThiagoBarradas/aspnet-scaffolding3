﻿using $ext_safeprojectname$.Services.Interfaces;

namespace $ext_safeprojectname$.Services
{
    public class PersonService : IPersonService
    {
    }
}
