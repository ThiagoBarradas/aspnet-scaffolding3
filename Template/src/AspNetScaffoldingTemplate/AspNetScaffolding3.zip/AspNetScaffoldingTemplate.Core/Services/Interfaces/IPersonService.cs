﻿namespace $ext_safeprojectname$.Services.Interfaces
{
    public interface IPersonService
    {
    }
}
