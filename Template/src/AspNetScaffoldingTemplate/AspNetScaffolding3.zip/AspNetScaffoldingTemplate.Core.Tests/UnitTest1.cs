using System;
using Xunit;

namespace $ext_safeprojectname$
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
